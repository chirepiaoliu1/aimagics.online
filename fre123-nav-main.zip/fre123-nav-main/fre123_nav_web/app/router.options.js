// 刷新自动滚动到最上面
export default {
	scrollBehavior() {
		return { top: 0 }
	},
}
