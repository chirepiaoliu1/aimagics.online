export default defineNuxtPlugin((nuxt) => {})
