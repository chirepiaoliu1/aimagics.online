## 项目说明

FRE123 后台管理系统

## 环境要求

- node: v18.16.0
- yarn: 1.22.19

## 二、安装步骤

- clone

```sh
cd fre123_nav_admin
```

- install

```sh
yarn install
```

- run

```sh
yarn dev
```