<template>
  <div>这是导航分类管理页面</div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
