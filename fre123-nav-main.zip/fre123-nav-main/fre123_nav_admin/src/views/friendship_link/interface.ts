export interface ISelectType {
    label: string;
    value: number;
}