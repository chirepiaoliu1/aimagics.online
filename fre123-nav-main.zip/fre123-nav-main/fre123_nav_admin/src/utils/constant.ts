export const NAV_STORE_ID = 'nav-store-id'
export const WEBSITE_STORE_ID = 'website-store-id' /* 广告列表 */
export const SURPRISE_STORE_ID = 'app-store-id'
export const FRIENDSHIP_USER_STORE = 'friendship-user-store'/* 用户列表 */