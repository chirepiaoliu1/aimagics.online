// * 后端微服务端口名
export const PORT1 = '/v1'
export const PORT_ADMIN = '/admin'
