//获取数据的接口地址
export const NAV_GET = 'v1/admin_nav/get'
//新增数据接口地址
export const NAV_UPDATE = 'v1/admin_nav/update'
//删除数据接口地址
export const NAV_DELATE = 'v1/admin_nav/delete'
//插入的接口'
export const NAV_INSERT = 'v1/admin_nav/insert'