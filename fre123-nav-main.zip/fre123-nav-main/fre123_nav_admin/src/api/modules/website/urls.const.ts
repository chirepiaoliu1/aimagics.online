export const WEBSITE_GET = "v1/admin_site_config/get";
export const WEBSITE_UPDATE = "v1/admin_site_config/update";

