export const CONFIG_ADMIN_GET = '/v1/config/get'
