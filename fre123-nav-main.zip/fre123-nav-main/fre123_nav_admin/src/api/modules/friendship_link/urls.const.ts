//登录列表
export const USER_FRIEND_SHIP = 'v1/admin_friendship_links/get'

//添加接口
export const USER_FRIEND_SHIP_INSERT = 'v1/admin_friendship_links/insert'

//删除接口
export const USER_FRIEND_SHIP_DELETE = 'v1/admin_friendship_links/delete'

//更新接口
export const USER_FRIEND_SHIP_UPDATE = 'v1/admin_friendship_links/update'

//分类拖拽接口
export const USER_FRIEND_SHIP_TYPE_SORT = 'v1/admin_friendship_links/sort'