export const USER_LOGIN = '/v1/admin_user/login'
