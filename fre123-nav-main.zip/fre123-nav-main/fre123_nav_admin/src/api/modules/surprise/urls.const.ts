// 广告 列表
export const SURPRISE_LIST = 'v1/admin_surprise/get'

//删除 广告
export const SURPRISE_DEL = 'v1/admin_surprise/delete'

//修改广告
export const SURPRISE_UPDATE = 'v1/admin_surprise/update'

//新增广告
export const SURPRISE_INSERT = 'v1/admin_surprise/insert'
