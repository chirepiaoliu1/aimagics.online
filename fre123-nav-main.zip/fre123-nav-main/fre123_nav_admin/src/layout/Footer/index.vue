<template>
  <!-- <div class="footer flx-center">
    <span>此处为footer组件</span>
  </div> -->
</template>

<style scoped lang="scss">
@import './index.scss';
</style>
