### 如何添加菜单

- 1. 在 menu.json 中添加相应的格式 json 数据

- 2. 在 src/routers/router.ts 中数组中添加相应的 数据

### icon

- 菜单的`icon`均使用`Element-plus`的`Icon`图标

```json
以首页和表格举例
"icon": "home-filled"
"icon": "message-box"
对应的图标为: HomeFilled、MessageBox
```

- 图标地址: [icon](https://element-plus.gitee.io/zh-CN/component/icon.html)
