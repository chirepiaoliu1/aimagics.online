module.exports = {
  plugins: {
    autoprefixer: {},
  },
}
