"""
    Created by burger at 2024-07-15.
    Description: 
        - web_base接口,包含删改查,数据存储在d_user集合中
    Changelog: all notable changes to this file will be documented
"""
