"""
    Created by burger at 2024-07-21.
    Description: 
        - friend_ship接口,包含删改查,数据存储在d_friend_ship集合中
    Changelog: all notable changes to this file will be documented
"""
