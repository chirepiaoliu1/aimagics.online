docker buildx build --no-cache=true --platform linux/amd64 -t howie6879/python:3.11-slim -f basic.Dockerfile .
